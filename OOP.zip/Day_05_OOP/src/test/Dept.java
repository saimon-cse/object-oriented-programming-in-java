package test;

public class Dept {
	static String dept = "CSE";
}
