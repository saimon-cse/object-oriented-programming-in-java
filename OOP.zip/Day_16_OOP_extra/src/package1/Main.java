package package1;

public class Main {

	public static void main(String[] args) {
		/*
		 * Object oriented Design
		 * SOLID priencipal
		 * 	S = single respomsibility principal
		 * O = Open/Clos principal
		 * L = Liskov s
		 */
		
		}

	}

