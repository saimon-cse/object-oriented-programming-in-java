package com.students;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Students ob = new Students();
		ob.show();
		ob.bsmru();
	}

}
