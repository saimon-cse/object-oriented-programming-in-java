package com.students;

public class Dept {
	final void bsmru() {
		System.out.println("Dept: CSE");
	}
}
