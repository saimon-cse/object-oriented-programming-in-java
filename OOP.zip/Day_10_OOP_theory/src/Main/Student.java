package Main;

public class Student extends Human{
	void show() {
		
		System.out.println("Student");
	}
}
