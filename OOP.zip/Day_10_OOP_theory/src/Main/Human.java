package Main;

public class Human {
	void show() {
		System.out.println("Human!");
	}
}
