package Main;

public class Teacher extends Human{
	void show() {
		System.out.println("Teacher!");
	}
}
