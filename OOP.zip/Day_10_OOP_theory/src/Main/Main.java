package Main;

public class Main {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human h = new Human();
		h.show();
		
		h = new Student();
		h.show();
		
		h = new Teacher();
		h.show();
		
		
		
	}

}
