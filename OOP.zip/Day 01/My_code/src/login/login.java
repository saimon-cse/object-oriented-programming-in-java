package login;

import javax.swing.*;

public class login {
    private JPanel panel1;
}
