package person;

public class Person {

	String name;
	int age;
	
	void show() {
		System.out.println("Name: "+ name+ "\nAge: "+age);
	}

}
