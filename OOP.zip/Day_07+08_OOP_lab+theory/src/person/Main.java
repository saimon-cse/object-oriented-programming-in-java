package person;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student();
		student1.name = "AAB";
		student1.age = 20;
		student1.roll = 30;
		
		student1.show();	// access it's own class
		
		
		//access it's parent class
		

	}

}
