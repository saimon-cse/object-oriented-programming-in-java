package constractor;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student("Saimon", 21, 27);
		
		student1.show();
		
		Person student2 = new Student("AAB", 22, 27);
	}

}
