package multiLevelInheritance;

public class Y extends X{

}
