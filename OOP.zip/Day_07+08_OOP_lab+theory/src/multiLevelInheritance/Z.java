package multiLevelInheritance;

public class Z extends Y{

}
