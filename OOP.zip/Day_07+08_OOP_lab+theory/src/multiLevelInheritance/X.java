package multiLevelInheritance;

public class X {

}
