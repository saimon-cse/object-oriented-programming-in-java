/**
 * 
 */
/**
 * 
 */
module Day_06_OOP_lab {
}