package pack02;

public interface A {
	void m(); 
//	abstract void  m();// eita na dile o hobe
}
