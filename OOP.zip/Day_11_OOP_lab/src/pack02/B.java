package pack02;

public interface B {
	abstract void  m();
	
//	void m() {}; eita dile error hobe
}
