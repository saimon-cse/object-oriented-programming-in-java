package pack02;

public class C implements A,B {
	public void m() {
		System.out.println("Hello World!");
	}
}
