package Abstraction;

public class C extends A {
	void method2() {
		System.out.println("Method - C");
	}
//	void method11() {
//		System.out.println("Method - C");
//	}
	
//	System.out.println("Method - C");
}
