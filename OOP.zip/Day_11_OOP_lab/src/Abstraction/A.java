package Abstraction;

public abstract class A {
	void method1() { // concrete method
		System.out.println("Method 1");	
	
	}
	abstract void method2(); 
}
