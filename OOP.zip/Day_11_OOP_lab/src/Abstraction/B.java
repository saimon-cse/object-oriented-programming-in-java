package Abstraction;

public class B extends A {
	void method2() {
		System.out.println("method - B");
	}
}
