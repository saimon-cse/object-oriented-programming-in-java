package package1;

 // access the package class & interface



import java.util.Scanner;
import java.util.*;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj1 = new Scanner(System.in);//namespace ar karone java.util.scaner lekha lage na
		
		java.util.Scanner obj2 = new java.util.Scanner(System.in); // name space na dile java.util.scaner dewa lagbe
		
		
	}

}
