package package1;

public class A {
	public void print() {
		System.out.println("Package-1");
	}
}
