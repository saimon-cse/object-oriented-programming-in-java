package package2;

public class B {

}
