package package2;

public class A {
	void print() {
		System.out.println("package-2");
	}
}
